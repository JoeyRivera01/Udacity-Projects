#!/usr/local/bin/python
# -*- coding: utf-8 -*-
# IPND Stage 2 Final Project - Fill-in-the-blanks Game

"""
Note: Global variables in all caps,
local variables are lower cased, 
and functions are camel cased
"""


#GLOBAL VARIABLES
#dictionary of game strings, mapped off of difficulty
GAME_STRING = {"easy":"___1___ science is the study of the theory, experimentation, and engineering that form the basis for the design and use of ___2___. It is the scientific and practical approach to ___3___ and its applications and the systematic study of the feasibility, structure, expression, and mechanization of the methodical procedures (or algorithms) that underlie the acquisition, representation, processing, storage, communication of, and access to information. An alternate, more succinct definition of ___4___ science is the study of automating algorithmic processes that scale. A ___4___ scientist specializes in the theory of ___3___ and the design of computational systems.",
              "medium":"A ___1___ is created with the def keyword. You specify the inputs a ___1___ takes by adding ___2___ separated by commas between the parentheses. ___1___s by default return ___3___ if you don't specify the value to return. ___2___ can be standard data types such as string, number, dictionary, tuple, and ___4___ or can be more complicated such as objects and lambda functions.",
              "hard":"___1___ is the subfield of computer science that, according to Arthur Samuel, gives 'computers the ability to learn without being explicitly programmed.' Evolved from the study of pattern recognition and computational learning theory in artificial intelligence, ___2___ explores the study and construction of ___3___ that can learn from and make predictions on ___4___ – such ___3___ overcome following strictly static program instructions by making ___4___-driven predictions or decisions, through building a model from sample inputs. ___1___ is employed in a range of computing tasks where designing and programming explicit ___3___ with good performance is difficult or infeasible; example applications include email filtering, detection of network intruders or malicious insiders working towards a ___4___ breach, optical character recognition (OCR), learning to rank, and computer vision."}

#dictionary of chance integers, mapped off of difficulty
LIVES = {"easy":7,
         "medium":5,
         "hard":2}

#array of blanks to be replaced by user guesses
BLANKS = ["___1___",
          "___2___",
          "___3___",
          "___4___"]

#array of prompts
ANSWER_PROMPTS = ["\nEnter guess for __1__: ",
                  "\nEnter guess for __2__: ",
                  "\nEnter guess for __3__: ",
                  "\nEnter guess for __4__: "]

#dictionary of answer arrays, mapped off of difficulty
ANSWERS = {"easy":["Computer","computers","computation","computer"],
           "medium":["function","arguments","None","list"],
           "hard":["Machine learning","machine learning","algorithms","data"]}

DIFFICULTY_PROMPT = "\nType in a difficulty ('easy', 'medium', or 'hard') and press Enter: "

AGAIN_PROMPT = "Would you like to play again? Type 'yes' or 'no' :"


#FUNCTIONS
def newGame():
    #1 Begins new game
    #input: none
    #output: results of the game
    print "Welcome to the fill-in-the-blanks quiz!"
    difficulty = difficultySelect(raw_input(DIFFICULTY_PROMPT).lower())
    lives = LIVES[difficulty]
    game_string = GAME_STRING[difficulty]
    print "\nOn " + difficulty + " difficulty, you have " + str(lives) + " lives. You will lose a life if you guess incorrectly."
    print "Fill in the blanks correctly to win!\n\n" + game_string
    return getAnswers(difficulty, lives, game_string)

def difficultySelect(user_choice):
    #2 Allows user to select the difficulty
    #input: user's difficulty choice
    #output: difficulty string
    if user_choice == "easy":
        return "easy"
    if user_choice == "medium":
        return "medium"
    if user_choice == "hard":
        return "hard"
    else:
        #Call the function again if the user inputs an incorrect string
        print "\nWhoops,", user_choice, "is not a valid difficulty, try again!"
        return difficultySelect(raw_input(DIFFICULTY_PROMPT).lower())    

def getAnswers(difficulty, lives, game_string):
    #3 Prompt user and store answers
    #input: difficulty setting, lives integer, game string
    #output: winner or game over
    i = 0
    answer = ""
    answers = []
    while len(answers) < len(ANSWERS[difficulty]):
        answer = str((raw_input(ANSWER_PROMPTS[i])))
        if rightAnswer(answer, answers, i, difficulty) == True:
            game_string = replaceString(answer, i, game_string)
            print "The current paragraph reads:\n\n" + game_string
            i += 1
        else:
            if lives > 1:
                print "\n" + str(answer) + " is incorrect. Try again!"
            else:
                print "\n" + str(answer) + " is incorrect."
            lives = wrongAnswer(lives)
            if lives == 0:
                return gameOver()
    return winner(lives)

def rightAnswer(answer, answers, i, difficulty):
    #4 Checks to see if answers are correct
    #input: current answer, array of answers, current index, and difficulty level
    #output: True if correct, otherwise False
    if answer == ANSWERS[difficulty][i]:
        answers.append(answer)
        print "\nCORRECT!\n"
        return True
    else:
        return False

def wrongAnswer(lives):
    #5 Reduces the lives of the player if a wrong answer is given
    #input: count of lives
    #output: count of lives reduced by one
    lives -= 1
    if lives > 1:
        print "\nYou have " + str(lives) + " lives left."
        return lives
    if lives == 1:
        print "\nYou have " + str(lives) + " life left! Be careful!"
        return lives
    else:
        return lives

def replaceString(answer,i,game_string):
    #6 Replaces correct answers in the game string's blanks
    #input: current answer, current index, and game string
    #output: updated gamestring
    replaced_word = ""
    processed_array = []
    new_game_string = ""
    for word in game_string.split():
        if BLANKS[i] in word:
            replaced_word = word.replace(word, answer)
            processed_array.append(replaced_word)
        else:
            processed_array.append(word)
    new_game_string = " ".join(processed_array)
    return new_game_string

def winner(lives):
    #7 Informs user they won and prompts them to play again
    #input: count of lives
    #output: you win message and play again prompt
    if lives > 1:
        print "\nWINNER!!!\n\nYou won with " + str(lives) + " lives remaining.\n"
    else:
        print "\nWINNER!!!\n\nYou won with " + str(lives) + " life remaining!!!\n"
    return playAgain(raw_input(AGAIN_PROMPT).lower())

def gameOver():
    #8 Informs user they lost and prompts them to play again
    #input: none
    #output: game over message and play again prompt 
    print "\nGame Over! Sad day.\n"
    return playAgain(raw_input(AGAIN_PROMPT).lower())

def playAgain(yes_no):
    #9 Prompts the user to play again or quit
    #input: user's yes or no choice
    #output: starts a new game if 'yes' and says goodbye if 'no'
    #otherwise: user's input is invalid, so prompt them again
    if yes_no == 'yes':
        return newGame()
    if yes_no == 'no':
        print "\nThanks for playing! You're ranked #1 (out of 1).\nClick 'X' in top-right corner to close the window."
        return
    else:
        print "\n" + str(yes_no) + " is an invalid choice. Please type 'yes' or 'no'."
        return playAgain(raw_input(AGAIN_PROMPT).lower())


newGame()



