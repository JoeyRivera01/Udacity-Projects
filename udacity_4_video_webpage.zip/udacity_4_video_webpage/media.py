import webbrowser

# This file holds the classes to make video objects

# Parent Class
class Video():
    """ This class provies a way to store video related information """
    # Constructor and instance variables
    def __init__(self, title, storyline, poster_image_url, trailer_youtube_url):
        self.title = title
        self.storyline = storyline
        self.poster_image_url = poster_image_url
        self.trailer_youtube_url = trailer_youtube_url

    # Instance methods
    def show_poster(self):
        webbrowser.open(self.poster_image_url)

    def show_trailer(self):
        webbrowser.open(self.trailer_youtube_url)

    
        
# Child classes which inherit from Video are below
class Movie(Video):
    """ This class provies a way to store movie related information """
    # Constructor
    def __init__(self, title, storyline, poster_image_url, trailer_youtube_url,
                 duration):
        # Inherited instance variables
        Video.__init__(self, title, storyline, poster_image_url, trailer_youtube_url)
        # Local instance variable
        self.duration = duration

    def show_duration(self):
        print self.duration
        
    
class TvShow(Video):
    """ This class provies a way to store TV related information """
    # Constructor and instance variables
    def __init__(self, title, storyline, poster_image_url, trailer_youtube_url,
                 num_seasons, num_episodes):
        # Inherited instance variables
        Video.__init__(self, title, storyline, poster_image_url, trailer_youtube_url)
        # Local instance variables
        self.num_seasons = num_seasons
        self.num_episodes = num_episodes

    def show_seasons(self):
        print self.num_seasons

    def show_episodes(self):
        print self.num_episodes
        
